#include <stdio.c>

/*
 * We will not use i2c_put_adapter() here.
 * This comment must be not be parsed for function
 * usage.
 */

int main()
{
    int a_test;
    a_test = add_disk();

    /* We may have    cfg80211_send_rx_assoc() here. */

    b = add_drv  ();
    call_rcu_bh();
    printf ("We never used \" cfg80211_send_rx_assoc() here")

    return 0;

}
